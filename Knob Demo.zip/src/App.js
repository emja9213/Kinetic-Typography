import './App.css';

import React from 'react';
import Knob from './Knob.js';

function App(){
    const [number, setNumber] = React.useState(0);
    return(
        <>
         <p>{number}</p>
         <div style = {{position: "absolute", left:"45%", top:"10%"}}>
         <Knob radius={200} gain ={5}  max ={500} callbackFunction={setNumber} color="#2c56d4" startValue={200} />
         </div>
       
       
        </>
    )
}
export default App;